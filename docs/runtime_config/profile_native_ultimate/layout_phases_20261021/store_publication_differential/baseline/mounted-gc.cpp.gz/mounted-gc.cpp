#include "/private/tmp/glyph-native-publication-baseline-a288.cpp"
bool GlyphMountedReadRangeProbe(const char *p,size_t o,uint8_t *b,size_t n){MountedStorage s;return s.ReadRange(p,o,b,n);}
