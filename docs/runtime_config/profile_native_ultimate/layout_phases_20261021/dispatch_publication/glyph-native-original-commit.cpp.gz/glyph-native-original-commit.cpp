// Receipt preparation and publication share the caller frame; transaction
// ordering and the single authoritative directory publication stay unchanged.
__attribute__((always_inline)) inline ProfileStore::TransactionResult ProfileStore::Commit(
    Directory &next,
    uint32_t id,
    uint32_t rev,
    const TransactionIdentity &t
) {
    next.generation = Generation() + 1;
    next.last_identity = t;
    next.last_result = { Status::Ok, id, rev, next.generation };
    static TransactionResult result; result = next.last_result;
    if (PublishDirectory(next)) return result;
    result = { _uncertain ? Status::UnknownOutcome : Status::IoFailure, id, rev, next.generation };
    return result;
}

