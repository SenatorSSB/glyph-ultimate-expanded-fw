from pathlib import Path
r=Path('/private/tmp/glyph-profile-native-20261020');p=r/'HAL/pico/src/comms/ConfiguratorBackend.cpp';s=p.read_text();s=s.replace('static bool profile_received;','static bool profile_received;\nstatic bool dispatch_handled, dispatch_pending;')
a='''    if (!DispatchProfileStore()) return false;
    return RespondProfileStore();'''
b='''    {
        struct DispatchReset {
            ~DispatchReset() { dispatch_handled = dispatch_pending = false; }
        } dispatch_reset;
#if GLYPH_STRICT_HARDENING_CANDIDATE
        struct FaultScope { ~FaultScope(){ProfileStoreFaultControls::EndMutation();} } fault_scope;
#endif
        if (!DispatchProfileStore()) return false;
        if (!ExecuteProfileStoreMutation()) return false;
        if (!FinalizeProfileStore()) return false;
    } // original fault scope ends before response encoding/TX
    return RespondProfileStore();''';assert s.count(a)==1;s=s.replace(a,b)
start=s.index('__attribute__((noinline)) bool ConfiguratorBackend::DispatchProfileStore()');end=s.index('__attribute__((noinline)) bool ConfiguratorBackend::RespondProfileStore()',start);old=s[start:end];Path('/private/tmp/glyph-native-original-dispatch.cpp').write_text(old)
old=old.replace('    bool handled = false;','    dispatch_handled = dispatch_pending = false;').replace('handled = true;','dispatch_handled = true;').replace('if (!handled)', 'if (!dispatch_handled)')
a='''    // Scope ends before encoding/TX, including failed/unused rules. Pending
    // rules never affect STATUS, QUERY, replay without ticket, or legacy SET.
#if GLYPH_STRICT_HARDENING_CANDIDATE
    struct FaultScope { ~FaultScope(){ProfileStoreFaultControls::EndMutation();} } fault_scope;
#endif
''';assert old.count(a)==1;old=old.replace(a,'')
a=old.index('        else if (admission == 1) {');b=old.index('    if (!dispatch_handled) {',a)
part=old[a:b];assert part.endswith('        }\n    }\n')
body=part[len('        else if (admission == 1) {\n'): -len('        }\n    }\n')]
# No second admission or durable read; ConfigWriteCandidate accessor is unchanged.
body='\n'.join(line[8:] if line.startswith('        ') else line for line in body.split('\n'))
prep=old[:a]+'''        else if (admission == 1) dispatch_pending = true;
    }
    return true;
}

__attribute__((noinline)) bool ConfiguratorBackend::ExecuteProfileStoreMutation() {
    if (!dispatch_pending) return true;
'''+body+'''    return true;
}

__attribute__((noinline)) bool ConfiguratorBackend::FinalizeProfileStore() {
'''+old[b:]
s=s[:start]+prep+s[end:];p.write_text(s)
p=r/'HAL/pico/include/comms/ConfiguratorBackend.hpp';s=p.read_text().replace('    bool DispatchProfileStore();','    bool DispatchProfileStore();\n    bool ExecuteProfileStoreMutation();\n    bool FinalizeProfileStore();');p.write_text(s)
