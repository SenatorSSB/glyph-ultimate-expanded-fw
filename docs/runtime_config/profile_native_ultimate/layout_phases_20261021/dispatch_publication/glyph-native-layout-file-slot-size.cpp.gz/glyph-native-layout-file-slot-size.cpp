#include "/private/tmp/glyph-profile-native-20261020/HAL/pico/src/core/Persistence.cpp"
char layout_new_file_slot_size[sizeof(save_file_slot)];
char layout_new_save_phase_size[sizeof(SavePhaseState)];
char layout_new_total_charge[sizeof(save_file_slot)+sizeof(SavePhaseState)+2+sizeof(unsigned)];
static_assert(sizeof(save_file_slot)+sizeof(SavePhaseState)+2+sizeof(unsigned)<=512,"layout static subcap");
