#include "/private/tmp/glyph-profile-native-20261020/HAL/pico/src/core/ProfileStore.cpp"
bool GlyphMountedReadRangeProbe(const char *p,size_t o,uint8_t *b,size_t n){MountedStorage s;return s.ReadRange(p,o,b,n); }
