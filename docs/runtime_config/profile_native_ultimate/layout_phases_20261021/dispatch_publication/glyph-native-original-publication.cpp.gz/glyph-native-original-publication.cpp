    __attribute__((always_inline)) inline Result Publish(
        ProfileStoreStorage &s,
        const char *tmp,
        const char *dest,
        const uint8_t *b,
        size_t n,
        Kind k,
        ProfileStoreIoStage *stage
    ) {
        publishing = {&s, tmp, dest, b, n, k, stage};
        static uint8_t readback[kMaxRecordWireBytes];
        if (publishing.stage)
            *publishing.stage = ProfileStoreIoStage::None;
        if (publishing.length > sizeof(readback)) {
            std::memset(&publishing, 0, sizeof(publishing));
            return { Outcome::Failed, 0, 0 };
        }
        const auto publication = publishing.kind == Kind::Root ? ProfileStorePublicationKind::Directory
                                                 : ProfileStorePublicationKind::Record;
        // C++17 constructs returned PODs directly in fixed scratch. Publication
        // inputs are reset each call and cleared on every exit. No callback
        // recursively enters the synchronous core0 store/publication path.
        static Result r;
        ::new (&r) Result(publishing.storage->CheckedWrite(publishing.tmp, publishing.bytes, publishing.length, publishing.kind));
        if (!r) {
            if (publishing.stage) {
                *publishing.stage = ProfileStoreStage(publication, publishing.storage->LastFailure());
                if (*publishing.stage == ProfileStoreIoStage::None)
                    *publishing.stage = ProfileStoreStage(publication, ProfileStoreIoStage::RecordTempWrite);
            }
            std::memset(&publishing, 0, sizeof(publishing));
            return r;
        }
        ::new (&r) Result(publishing.storage->CheckedRead(publishing.tmp, readback, publishing.length, publishing.kind));
        if (!r) {
            if (publishing.stage) {
                *publishing.stage = ProfileStoreStage(publication, publishing.storage->LastFailure());
                if (*publishing.stage == ProfileStoreIoStage::None)
                    *publishing.stage = publication == ProfileStorePublicationKind::Directory
                                 ? ProfileStoreIoStage::DirectoryTempRead
                                 : ProfileStoreIoStage::RecordTempRead;
            }
            std::memset(&publishing, 0, sizeof(publishing));
            return r;
        }
        if (std::memcmp(publishing.bytes, readback, publishing.length) != 0) {
            if (publishing.stage)
                *publishing.stage = ProfileStoreStage(publication, ProfileStoreIoStage::RecordVerify);
            std::memset(&publishing, 0, sizeof(publishing));
            return { Outcome::Failed, 0, 0 };
        }
        ::new (&r) Result(publishing.storage->CheckedRename(publishing.tmp, publishing.dest, publishing.kind));
        if (!r && publishing.stage)
            *publishing.stage = ProfileStoreStage(
                publishing.kind == Kind::Root ? ProfileStorePublicationKind::Directory
                                : ProfileStorePublicationKind::Record,
                ProfileStoreIoStage::RecordRename
            );
        std::memset(&publishing, 0, sizeof(publishing));
        return r;
    }