ProfileStore::TransactionResult ProfileStore::Rename(
    uint32_t id,
    const char *name,
    uint32_t generation,
    const TransactionIdentity &t
) {
    static TransactionResult r; ::new (&r) TransactionResult(Start(t));
    if (r.status != Status::NotFound)
        return r;
    int i = Find(id);
    if (i < 0)
        return { Status::NotFound };
    if (generation != Generation())
        return { Status::Conflict };
    if (!ValidName(name))
        return { Status::Invalid };
    if (!Admit(0, 0))
        return { Status::Full };
    *_next = *_directory;
    std::memset(_next->entries[i].name, 0, 33);
    std::memcpy(_next->entries[i].name, name, std::strlen(name));
    return Commit(*_next, id, _next->entries[i].revision, t);
}

ProfileStore::TransactionResult ProfileStore::Reorder(
    uint32_t id,
    uint32_t rank,
    uint32_t generation,
    const TransactionIdentity &t
) {
    static TransactionResult r; ::new (&r) TransactionResult(Start(t));
    if (r.status != Status::NotFound)
        return r;
    int i = Find(id);
    if (i < 0)
        return { Status::NotFound };
    if (generation != Generation())
        return { Status::Conflict };
    if (!Admit(0, 0))
        return { Status::Full };
    *_next = *_directory;
    _next->entries[i].rank = rank;
    return Commit(*_next, id, _next->entries[i].revision, t);
}

ProfileStore::TransactionResult ProfileStore::Delete(
    uint32_t id,
    uint32_t generation,
    uint32_t referenced,
    const TransactionIdentity &t
) {
    static TransactionResult r; ::new (&r) TransactionResult(Start(t));
    if (r.status != Status::NotFound)
        return r;
    int i = Find(id);
    if (i < 0)
        return { Status::NotFound };
    if (generation != Generation())
        return { Status::Conflict };
    if (id == referenced || id == _active_id)
        return { Status::Referenced };
    if (!Admit(0, 0))
        return { Status::Full };
    *_next = *_directory;
    for (size_t j = i + 1; j < _next->count; ++j)
        _next->entries[j - 1] = _next->entries[j];
    --_next->count;
    return Commit(*_next, id, 0, t);
}
