from pathlib import Path
r=Path('/private/tmp/glyph-profile-native-20261020');p=r/'HAL/pico/src/core/ProfileStore.cpp';s=p.read_text();a=s.index('// Receipt preparation and publication share');b=s.index('__attribute__((noinline)) void ProfileStore::PrepareCreate()',a);Path('/private/tmp/glyph-native-original-commit.cpp').write_text(s[a:b]);s=s[:a]+'''namespace { ProfileStore::TransactionResult committing_result{}; }

__attribute__((noinline)) void ProfileStore::PrepareCommit(
    Directory &next, uint32_t id, uint32_t rev, const TransactionIdentity &t
) {
    next.generation = Generation() + 1;
    next.last_identity = t;
    next.last_result = { Status::Ok, id, rev, next.generation };
    committing_result = next.last_result;
}

__attribute__((noinline)) ProfileStore::TransactionResult ProfileStore::PublishPreparedCommit(const Directory &next) {
    if (PublishDirectory(next)) return committing_result;
    committing_result = { _uncertain ? Status::UnknownOutcome : Status::IoFailure,
        committing_result.id, committing_result.revision, next.generation };
    return committing_result;
}

__attribute__((always_inline)) inline ProfileStore::TransactionResult ProfileStore::Commit(
    Directory &next, uint32_t id, uint32_t rev, const TransactionIdentity &t
) {
    PrepareCommit(next, id, rev, t);
    return PublishPreparedCommit(next);
}

'''+s[b:]
a=s.index('ProfileStore::TransactionResult ProfileStore::Rename(\n');b=s.index('\nnamespace {\n    bool HashFile',a);old=s[a:b];Path('/private/tmp/glyph-native-original-metadata.cpp').write_text(old)
wrappers=[];pieces=[]
for name in ['Rename','Reorder','Delete']:
 start=old.index('ProfileStore::TransactionResult ProfileStore::'+name+'(\n');end=old.find('\nProfileStore::TransactionResult ',start+1);method=old[start:end if end>=0 else len(old)];signature=method[:method.index(') {')+3];body=method[method.index(') {')+3:]
 prep_signature=signature.replace('ProfileStore::TransactionResult ProfileStore::'+name,'__attribute__((noinline)) bool ProfileStore::Prepare'+name)
 body=body.replace('    static TransactionResult r; ::new (&r) TransactionResult(Start(t));','    ::new (&committing_result) TransactionResult(Start(t));\n    auto &r = committing_result;').replace('        return r;','        return false;')
 import re
 body=re.sub(r'return \{ (Status::\w+) \};',r'{ r = { \1 }; return false; }',body)
 last=re.search(r'    return Commit\(\*_next, id, (.*?), t\);\n}',body);assert last,name
 body=body[:last.start()]+'    PrepareCommit(*_next, id, '+last.group(1)+', t);\n    return true;\n}'
 pieces.append(prep_signature+body)
 args={'Rename':'id, name, generation, t','Reorder':'id, rank, generation, t','Delete':'id, generation, referenced, t'}[name]
 wrappers.append(signature+'\n    if (Prepare'+name+'('+args+')) return PublishPreparedCommit(*_next);\n    return committing_result;\n}\n')
s=s[:a]+'\n\n'.join(pieces+wrappers)+s[b:];p.write_text(s)
p=r/'include/core/ProfileStore.hpp';s=p.read_text();i=s.index('    TransactionResult Commit(');s=s[:i]+'''    void PrepareCommit(Directory &, uint32_t id, uint32_t revision, const TransactionIdentity &);
    TransactionResult PublishPreparedCommit(const Directory &);
    bool PrepareRename(uint32_t id, const char *name, uint32_t generation, const TransactionIdentity &);
    bool PrepareReorder(uint32_t id, uint32_t rank, uint32_t generation, const TransactionIdentity &);
    bool PrepareDelete(uint32_t id, uint32_t generation, uint32_t referenced, const TransactionIdentity &);
'''+s[i:];p.write_text(s)
