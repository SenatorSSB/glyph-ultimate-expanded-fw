from pathlib import Path
r=Path('/private/tmp/glyph-profile-native-20261020');p=r/'HAL/pico/src/core/ProfileStore.cpp';s=p.read_text()
marker='    PreparedPublication publishing{};';assert s.count(marker)==1
s=s.replace(marker,marker+'''\n    // Existing owned publication buffers, shared only by synchronous phases.
    uint8_t control_publication_wire[kDirectoryWireBytes + 16];
    uint8_t directory_publication_wire[kDirectoryWireBytes];
    char directory_publication_path[32], directory_publication_temp[32];
    uint8_t initialize_root_wire[kDirectoryWireBytes];
''')
a=s.index('__attribute__((always_inline)) inline bool ProfileStore::WriteControl(');b=s.index('// Keep bootstrap publication',a)
old=s[a:b];s=s[:a]+'''__attribute__((noinline)) bool ProfileStore::PrepareControlPublication(const Directory &seed, uint32_t phase) {
    auto &wire = control_publication_wire;
    if (!EncodeDirectory(seed, wire + 16))
        return false;
    Put32(wire, kControlMagic);
    Put32(wire + 4, phase);
    Put32(wire + 8, kDirectoryWireBytes);
    Put32(wire + 12, Crc32(wire, 12) ^ Crc32(wire + 16, kDirectoryWireBytes));
    publishing = {_storage, kControlTemp, kControl, wire, sizeof(wire), Kind::Root, &_last_io_stage};
    return true;
}

__attribute__((noinline)) bool ProfileStore::WriteControl(const Directory &seed, uint32_t phase) {
    if (!PrepareControlPublication(seed, phase)) return false;
    ExecutePublication();
    if (publication_result.outcome == Outcome::Uncertain) _uncertain = true;
    return bool(publication_result);
}

'''+s[b:]
a=s.index('__attribute__((always_inline)) inline bool ProfileStore::InitializeV2(');b=s.index('__attribute__((noinline)) ProfileStore::BootstrapAction',a)
old=s[a:b];prep=old[:old.index('    for (unsigned slot')]
prep=prep.replace('__attribute__((always_inline)) inline bool ProfileStore::InitializeV2','__attribute__((noinline)) bool ProfileStore::PrepareInitializeV2').replace('    static uint8_t wire[kDirectoryWireBytes];','    auto &wire = initialize_root_wire;')
body=old[old.index('    for (unsigned slot'):]
body=body.replace('wire, sizeof(wire)','initialize_root_wire, sizeof(initialize_root_wire)')
s=s[:a]+prep+'''    return true;
}

__attribute__((always_inline)) inline bool ProfileStore::InitializeV2(const Directory &seed) {
    if (!PrepareInitializeV2(seed)) return false;
'''+body+s[b:]
a=s.index('bool ProfileStore::PublishDirectory(');b=s.index('\nbool ProfileStore::IsReady()',a);old=s[a:b]
new='''__attribute__((noinline)) bool ProfileStore::PrepareDirectoryPublication(const Directory &next) {
    if (!_ready || _read_only_recovery || _uncertain || !_v2) return false;
    if (!EncodeDirectory(next, directory_publication_wire)) return false;
    unsigned slot = next.generation & 1u;
    RootPath(directory_publication_path, sizeof(directory_publication_path), slot);
    RootTemp(directory_publication_temp, sizeof(directory_publication_temp), slot);
    return true;
}

bool ProfileStore::PublishDirectory(const Directory &next) {
    if (!PrepareDirectoryPublication(next)) return false;
    // Persist intended authority before the root, then its completed control.
    if (!WriteControl(next, 3)) {
        _uncertain = true;
        return false;
    }
    publishing = {_storage, directory_publication_temp, directory_publication_path,
        directory_publication_wire, sizeof(directory_publication_wire), Kind::Root, &_last_io_stage};
    ExecutePublication();
    if (!publication_result) {
        _uncertain = true;
        return false;
    }
    *_directory = next;
    _protected_ready = false;
    if (!WriteControl(next, 2)) {
        _uncertain = true;
        return false;
    }
    return true;
}
'''
s=s[:a]+new+s[b:];p.write_text(s)
p=r/'include/core/ProfileStore.hpp';s=p.read_text().replace('    bool WriteControl(const Directory &, uint32_t phase);','    bool WriteControl(const Directory &, uint32_t phase);\n    bool PrepareControlPublication(const Directory &, uint32_t phase);\n    bool PrepareDirectoryPublication(const Directory &);\n    bool PrepareInitializeV2(const Directory &);');p.write_text(s)
