__attribute__((noinline)) bool ConfiguratorBackend::DispatchProfileStore() {
    response = ProfileStoreResponse_init_default;
    response.protocol_version = request.protocol_version;
    response.mutation_protocol_version = 2;
    response.store_incarnation = _recovery_storage_available ? profile_store.Incarnation() : 0;
    response.request_token = request.request_token;
    response.store_generation = profile_store.Generation();
    const bool pulse = request.operation == PROFILE_STORE_LIVENESS;
    response.config_generation = pulse ? 0 : persistence.ConfigGeneration(_config);
    response.status = PROFILE_STORE_UNSUPPORTED;
    profile_store.ResetDiagnostic();
    const bool mutation = request.operation >= PROFILE_STORE_CREATE &&
        request.operation <= PROFILE_STORE_SET_MODE_REFERENCE;
    const bool query = request.operation == PROFILE_STORE_QUERY_TRANSACTION;
    identity = {};
    result = {};
    bool handled = false;
#if GLYPH_STRICT_HARDENING_CANDIDATE
    const bool ticket_invalid = request.fault_ticket &&
        (!mutation || request.protocol_version != 2 || !kStrictHardeningCandidate);
#else
    // Retired acceptance controls must never silently request a real mutation
    // or trigger reconciliation. Keep their wire tags inert and reject them
    // before either receipt domain can perform storage work.
    const bool ticket_invalid = request.fault_kind || request.fault_operation ||
        request.fault_phase || request.fault_result || request.fault_path_class ||
        request.fault_skip || request.fault_clear || request.fault_ticket || request.liveness_trace;
#endif
    // Scope ends before encoding/TX, including failed/unused rules. Pending
    // rules never affect STATUS, QUERY, replay without ticket, or legacy SET.
#if GLYPH_STRICT_HARDENING_CANDIDATE
    struct FaultScope { ~FaultScope(){ProfileStoreFaultControls::EndMutation();} } fault_scope;
#endif
    if (!TraceProfileStage(request, 2)) return false; // CRC complete; before reconciliation

    // Reconcile durable publications before using RAM for replay or admitting
    // another mutation. A failed authoritative reread leaves the fence intact.
    if (!ticket_invalid && _recovery_storage_available && (mutation || query)) {
        if (profile_store.IsTransactionUncertain()) profile_store.ReconcileTransaction();
        if (_reference_unknown || persistence.IsMutationFenced()) {
            Config &durable = ConfigWriteCandidate();
            if (persistence.ReconcileConfig(durable) == Persistence::SaveResult::Saved)
                _reference_unknown = false;
        }
    }
    if (ticket_invalid) {
        response.status = PROFILE_STORE_INVALID;
        handled = true;
    } else if (pulse) {
        response.status = kStrictHardeningCandidate && request.protocol_version == 2 ? PROFILE_STORE_OK : PROFILE_STORE_UNSUPPORTED;
#if GLYPH_STRICT_HARDENING_CANDIDATE
        response.strict_hardening_candidate = kStrictHardeningCandidate;
        if (kStrictHardeningCandidate) {
            response.rx_phase = _last_profile_rx.phase;
            response.rx_raw_bytes = _last_profile_rx.raw;
            response.rx_decoded_bytes = _last_profile_rx.decoded;
            response.rx_elapsed_ms = _last_profile_rx.elapsed;
            response.rx_task_passes = _last_profile_rx.task_passes;
            response.rx_last_progress_ms = _last_profile_rx.last_progress;
            response.rx_fetched_bytes = _last_profile_rx.fetched;
            response.rx_flags = _last_profile_rx.flags;
        }
#endif
        handled = true;
#if !GLYPH_STRICT_HARDENING_CANDIDATE
    } else if (request.operation == PROFILE_STORE_ARM_STORAGE_FAULT) {
        response.status = PROFILE_STORE_UNSUPPORTED;
        handled = true;
#endif
    } else if (mutation && request.protocol_version != 2) {
        response.status = PROFILE_STORE_UNSUPPORTED;
        handled = true;
    } else if (request.operation == PROFILE_STORE_STATUS) {
        response.status = _recovery_storage_available && profile_store.IsReady() &&
            !profile_store.IsReadOnlyRecovery() && !_recovery_config_invalid &&
            !persistence.IsMutationFenced() && !_reference_unknown &&
            !profile_store.IsTransactionUncertain() ? PROFILE_STORE_OK : PROFILE_STORE_IO_FAILURE;
        if (!_recovery_storage_available) strlcpy(response.diagnostic, "filesystem.unavailable", sizeof(response.diagnostic));
        else if (_recovery_config_invalid) strlcpy(response.diagnostic, "config.invalid", sizeof(response.diagnostic));
        else if (persistence.IsMutationFenced() || _reference_unknown) strlcpy(response.diagnostic, "config.commit_unknown", sizeof(response.diagnostic));
        else if (profile_store.IsTransactionUncertain()) strlcpy(response.diagnostic, "directory.commit_unknown", sizeof(response.diagnostic));
        else if (profile_store.MigrationPending()) strlcpy(response.diagnostic, "migration.fenced", sizeof(response.diagnostic));
        else if (profile_store.IsReadOnlyRecovery()) strlcpy(response.diagnostic, "directory.recovery", sizeof(response.diagnostic));
        if (_recovery_storage_available) {
            if (!TraceProfileStage(request, 3)) return false; // before filesystem capacity
            static ProfileStore::CapacityInfo capacity; CaptureStoreCapacity(capacity);
            if (!TraceProfileStage(request, 4)) return false; // capacity complete
            response.filesystem_total_bytes = capacity.total_bytes;
            response.filesystem_used_bytes = capacity.used_bytes;
            response.filesystem_free_bytes = capacity.free_bytes;
            response.filesystem_block_bytes = capacity.block_size;
            response.filesystem_program_bytes = capacity.page_size;
            response.reserved_bytes = capacity.reserve_bytes;
            response.protected_bytes = capacity.protected_bytes;
            response.staging_bytes = capacity.staging_bytes;
            response.admissible_profiles = capacity.admissible_profiles;
            response.mutation_feasible = capacity.mutation_feasible && !_recovery_service && !_recovery_config_invalid &&
                !_reference_unknown && !persistence.IsMutationFenced();
        }
        response.transaction_token_high_water = profile_store.LastTransactionToken();
        if (_recovery_storage_available && !_recovery_config_invalid) {
            if (!TraceProfileStage(request, 5)) return false; // before durable Config read
            Config &durable = ConfigWriteCandidate();
            if (persistence.LoadConfigChecked(durable) == Persistence::LoadResult::Loaded) {
                if (durable.profile_reference_token > response.transaction_token_high_water)
                    response.transaction_token_high_water = durable.profile_reference_token;
                if (durable.ultimate_profile_root_format != 2) {
                    response.mutation_feasible = false;
                    response.recovery_flags |= 1u << 20;
                }
            }
        }
        if (!TraceProfileStage(request, 6)) return false; // Config complete; before diagnostics
#if GLYPH_STRICT_HARDENING_CANDIDATE
        const auto resources = ReadResourceDiagnostics();
        if (!TraceProfileStage(request, 7)) return false; // diagnostics complete
        response.core0_stack_min_free_bytes = resources.core0_stack_min_free_bytes;
        response.core1_stack_min_free_bytes = resources.core1_stack_min_free_bytes;
        response.heap_arena_peak_bytes = resources.heap_arena_peak_bytes;
        response.heap_arena_current_bytes = resources.heap_arena_current_bytes;
        response.heap_arena_capacity_bytes = resources.heap_arena_capacity_bytes;
        response.resource_diagnostics_enabled = resources.resource_diagnostics_enabled;
        response.strict_hardening_candidate = kStrictHardeningCandidate;
#endif
        handled = true;
    } else if (!_recovery_storage_available) {
        result.status = ProfileStore::Status::IoFailure;
        strlcpy(response.diagnostic, "filesystem.unavailable", sizeof(response.diagnostic));
    } else if (request.operation == PROFILE_STORE_ARM_STORAGE_FAULT) {
#if GLYPH_STRICT_HARDENING_CANDIDATE
        if (!kStrictHardeningCandidate || request.protocol_version != 2)
            response.status = PROFILE_STORE_UNSUPPORTED;
        else if (_recovery_service) response.status = PROFILE_STORE_IO_FAILURE;
        else response.status = ProfileStoreFaultControls::Arm(request.fault_kind,request.fault_operation,
            request.fault_phase,request.fault_result,request.fault_path_class,request.fault_skip,request.fault_clear)
                ? PROFILE_STORE_OK : PROFILE_STORE_INVALID;
#else
        response.status = PROFILE_STORE_UNSUPPORTED;
#endif
        handled = true;
    } else if (request.operation == PROFILE_STORE_LIST) {
        const size_t cursor = request.page_cursor;
        const size_t count = request.page_size == 0 ? 8 : request.page_size;
        if (!profile_store.IsReady()) response.status = PROFILE_STORE_IO_FAILURE;
        else if (count > 8 || cursor > profile_store.Count()) response.status = PROFILE_STORE_INVALID;
        else {
            const size_t end = cursor + count < profile_store.Count() ? cursor + count : profile_store.Count();
            for (size_t i = cursor; i < end; ++i) {
                const ProfileStore::Entry *entry = profile_store.EntryAt(i);
                ProfileStoreEntry &out = response.entries[response.entries_count++];
                out.profile_id = entry->id; out.revision = entry->revision; out.display_rank = entry->rank;
                out.payload_version = entry->payload_version;
                strlcpy(out.name, entry->name, sizeof(out.name));
                // Zero means uninspected. Enumeration never reads payloads.
            }
            response.next_page_cursor = end < profile_store.Count() ? end : 0;
            response.status = PROFILE_STORE_OK;
        }
        handled = true;
    } else if (request.operation == PROFILE_STORE_INSPECT_HEALTH) {
        response.profile_id = request.profile_id;
        response.profile_health = static_cast<uint32_t>(profile_store.Health(request.profile_id)) + 1;
        response.status = PROFILE_STORE_OK;
        handled = true;
    } else if (request.operation == PROFILE_STORE_READ) {
        if (!ReadStoreProfile()) return false;
    } else if (!mutation && !query) {
        response.status = PROFILE_STORE_UNSUPPORTED;
        handled = true;
    } else if (!request.request_token || !PrepareStoreIdentity(request, identity)) {
        result.status = ProfileStore::Status::Invalid;
    } else {
        const unsigned admission = PrepareStoreMutation();
        if (admission == 2) handled = true;
        else if (admission == 1) {
            Config &candidate = ConfigWriteCandidate();
            if (request.operation == PROFILE_STORE_CREATE) {
                if (!TraceProfileDispatch(request)) return false;
                if (request.has_profile) ::new (&result) ProfileStore::TransactionResult(profile_store.Create(request.profile, request.name,
                    request.display_rank, identity)); else result = {ProfileStore::Status::Invalid};
            } else if (request.operation == PROFILE_STORE_UPDATE) {
                if (!TraceProfileDispatch(request)) return false;
                if (request.has_profile) ::new (&result) ProfileStore::TransactionResult(profile_store.Update(request.profile_id, request.profile,
                    static_cast<uint32_t>(request.expected_profile_revision), identity)); else result = {ProfileStore::Status::Invalid};
            } else if (request.operation == PROFILE_STORE_DUPLICATE) {
                if (!TraceProfileDispatch(request)) return false;
                ::new (&result) ProfileStore::TransactionResult(profile_store.Duplicate(request.profile_id,
                    static_cast<uint32_t>(request.expected_profile_revision), request.name, request.display_rank, identity));
            } else if (request.operation == PROFILE_STORE_RENAME) {
                if (!TraceProfileDispatch(request)) return false;
                ::new (&result) ProfileStore::TransactionResult(profile_store.Rename(request.profile_id, request.name,
                    static_cast<uint32_t>(request.expected_store_generation), identity));
            } else if (request.operation == PROFILE_STORE_REORDER) {
                if (!TraceProfileDispatch(request)) return false;
                ::new (&result) ProfileStore::TransactionResult(profile_store.Reorder(request.profile_id, request.display_rank,
                    static_cast<uint32_t>(request.expected_store_generation), identity));
            } else if (request.operation == PROFILE_STORE_DELETE) {
                if (!TraceProfileDispatch(request)) return false;
                const uint32_t referenced = ReferencesProfile(_config, request.profile_id) ||
                    ReferencesProfile(candidate, request.profile_id) ? request.profile_id : 0;
                ::new (&result) ProfileStore::TransactionResult(profile_store.Delete(request.profile_id,
                    static_cast<uint32_t>(request.expected_store_generation), referenced, identity));
            } else if (request.operation == PROFILE_STORE_SET_MODE_REFERENCE) {
                if (!TraceProfileDispatch(request)) return false;
                PerformCheckedReference();
            }
        }
    }
    if (!handled) {
        response.profile_id = result.id;
        response.profile_revision = result.revision;
        response.store_generation = result.status == ProfileStore::Status::Ok ? result.generation : profile_store.Generation();
        response.config_generation = persistence.ConfigGeneration(_config);
        switch (result.status) {
            case ProfileStore::Status::Ok:
            case ProfileStore::Status::RecoveredPrevious: response.status = PROFILE_STORE_OK; break;
            case ProfileStore::Status::NotFound: response.status = PROFILE_STORE_NOT_FOUND; break;
            case ProfileStore::Status::Referenced: response.status = PROFILE_STORE_REFERENCED; break;
            case ProfileStore::Status::Conflict: response.status = PROFILE_STORE_CONFLICT; break;
            case ProfileStore::Status::Full: response.status = PROFILE_STORE_FULL; break;
            case ProfileStore::Status::Aborted: response.status = PROFILE_STORE_TRANSACTION_ABORTED; break;
            case ProfileStore::Status::UnknownOutcome: response.status = PROFILE_STORE_COMMIT_UNKNOWN; break;
            case ProfileStore::Status::IoFailure:
            case ProfileStore::Status::ReadOnlyRecovery:
            case ProfileStore::Status::MigrationFenced: response.status = PROFILE_STORE_IO_FAILURE; break;
            default: response.status = PROFILE_STORE_INVALID; break;
        }
        if (!response.diagnostic[0] && (response.status == PROFILE_STORE_IO_FAILURE || response.status == PROFILE_STORE_COMMIT_UNKNOWN))
            strlcpy(response.diagnostic, profile_store.LastDiagnostic(), sizeof(response.diagnostic));
    }
#if GLYPH_STRICT_HARDENING_CANDIDATE
    ProfileStoreFaultControls::EndMutation();
    response.storage_fault_ticket = ProfileStoreFaultControls::Current().ticket;
    response.storage_fault_pending = ProfileStoreFaultControls::Current().pending;
    response.fault_control_version = kStrictHardeningCandidate ? 2 : 0;
    response.storage_fault_capable = kStrictHardeningCandidate;
    response.storage_fault_armed = ProfileStoreFaultControls::Current().armed;
    response.storage_fault_triggered = ProfileStoreFaultControls::Current().triggered;
    response.storage_fault_operation = ProfileStoreFaultControls::Current().operation;
#endif
    response.recovery_flags |= _recovery_storage_available ? profile_store.HealthFlags() : 0;
    // Bits 16+ are the Configurator layer; store flags occupy the low 16 bits.
    if (_recovery_config_invalid) response.recovery_flags |= 1u << 16;
    if (_recovery_service) response.recovery_flags |= 1u << 19;
    if (!_recovery_storage_available) response.recovery_flags |= 1u << 17;
    if (_reference_unknown || persistence.IsMutationFenced()) response.recovery_flags |= 1u << 18;
    return true;
}
