from pathlib import Path
r=Path('/private/tmp/glyph-profile-native-20261020');p=r/'HAL/pico/src/comms/ConfiguratorBackend.cpp';s=p.read_text().replace('__attribute__((noinline)) bool ConfiguratorBackend::ExecuteProfileStoreMutation()','__attribute__((always_inline)) inline bool ConfiguratorBackend::ExecuteProfileStoreMutation()');p.write_text(s)
p=r/'HAL/pico/src/core/ProfileStore.cpp';s=p.read_text();s=s.replace('namespace { ProfileStore::TransactionResult committing_result{}; }','''namespace {
ProfileStore::TransactionResult committing_result{};
struct MetadataInputs {
    uint32_t id, value, generation;
    const char *name;
    const ProfileStore::TransactionIdentity *identity;
};
MetadataInputs metadata_inputs{};
}''')
a=s.index('__attribute__((noinline)) ProfileStore::TransactionResult ProfileStore::PublishPreparedCommit');b=s.index('__attribute__((always_inline)) inline ProfileStore::TransactionResult ProfileStore::Commit',a)
new='''__attribute__((noinline)) void ProfileStore::PublishPreparedCommit(const Directory &next) {
    if (!PublishDirectory(next))
        committing_result = { _uncertain ? Status::UnknownOutcome : Status::IoFailure,
            committing_result.id, committing_result.revision, next.generation };
}

''';s=s[:a]+new+s[b:];s=s.replace('    return PublishPreparedCommit(next);','    PublishPreparedCommit(next);\n    return committing_result;',1)
for name,locals in [('Rename','const uint32_t id = metadata_inputs.id, generation = metadata_inputs.generation;\n    const char *name = metadata_inputs.name;'),('Reorder','const uint32_t id = metadata_inputs.id, rank = metadata_inputs.value, generation = metadata_inputs.generation;'),('Delete','const uint32_t id = metadata_inputs.id, generation = metadata_inputs.generation, referenced = metadata_inputs.value;')]:
 a=s.index('__attribute__((noinline)) bool ProfileStore::Prepare'+name+'(');b=s.index(') {',a);s=s[:a]+'__attribute__((noinline)) bool ProfileStore::Prepare'+name+'() {\n    '+locals+'\n    const auto &t = *metadata_inputs.identity;'+s[b+3:]
for name,call,setup in [('Rename','id, name, generation, t','{id, 0, generation, name, &t}'),('Reorder','id, rank, generation, t','{id, rank, generation, nullptr, &t}'),('Delete','id, generation, referenced, t','{id, referenced, generation, nullptr, &t}')]:
 a='''    if (Prepare'''+name+'('+call+''')) return PublishPreparedCommit(*_next);
    return committing_result;'''
 b='''    metadata_inputs = '''+setup+''';
    const bool prepared = Prepare'''+name+'''();
    std::memset(&metadata_inputs, 0, sizeof(metadata_inputs));
    if (prepared) PublishPreparedCommit(*_next);
    return committing_result;''';assert s.count(a)==1;s=s.replace(a,b)
# Retire Begin's initialization arguments before its bootstrap execution.
a=s.index('bool ProfileStore::Begin(uint32_t');b=s.index('bool ProfileStore::ReadRoot(',a);old=s[a:b]
body=old[old.index('    Directory *work = Workspace();'):old.index('    return ExecuteBootstrap(PrepareBootstrap(false));')]
body=body.replace('    if (!_storage)\n        _storage = &storage;\n','').replace('    _read_only_recovery = false;','    _read_only_recovery = recovery;').replace('    _recovery_only = false;','    _recovery_only = recovery;')
new='''__attribute__((noinline)) void ProfileStore::PrepareBeginState(uint32_t expected, uint32_t required_root_format, bool recovery) {
'''+body+'''}

bool ProfileStore::Begin(uint32_t expected, uint32_t required_root_format) {
    static MountedStorage storage;
    if (!_storage) _storage = &storage;
    PrepareBeginState(expected, required_root_format, false);
    return ExecuteBootstrap(PrepareBootstrap(false));
}

bool ProfileStore::BeginRecovery(uint32_t expected, uint32_t required_root_format) {
    static MountedStorage storage;
    if (!_storage) _storage = &storage;
    PrepareBeginState(expected, required_root_format, true);
    return ExecuteBootstrap(PrepareBootstrap(true));
}

'''
s=s[:a]+new+s[b:]
# Existing root paths become prepare-only owned scratch; no added path buffers.
a=s.index('__attribute__((always_inline)) inline bool ProfileStore::InitializeV2(');b=s.index('__attribute__((noinline)) ProfileStore::BootstrapAction',a);old=s[a:b]
new='''__attribute__((noinline)) void ProfileStore::PrepareInitializedRoot(unsigned slot) {
    static char p[32], t[32];
    RootPath(p, sizeof(p), slot);
    RootTemp(t, sizeof(t), slot);
    publishing = {_storage, t, p, initialize_root_wire, sizeof(initialize_root_wire), Kind::Root, &_last_io_stage};
}

__attribute__((always_inline)) inline bool ProfileStore::InitializeV2(const Directory &seed) {
    static unsigned slot; slot = 0;
    if (!PrepareInitializeV2(seed)) return false;
    for (; slot < 2; ++slot) {
        PrepareInitializedRoot(slot);
        ExecutePublication();
        if (!publication_result) {
            _uncertain = publication_result.outcome == Outcome::Uncertain;
            _read_only_recovery = true;
            slot = 0;
            return false;
        }
    }
    slot = 0;
    if (!WriteControl(seed, 2)) {
        _read_only_recovery = true;
        return false;
    }
    return LoadDirectory();
}

'''
s=s[:a]+new+s[b:];s=s.replace('__attribute__((noinline)) bool ProfileStore::ExecuteBootstrap(BootstrapAction action)','__attribute__((always_inline)) inline bool ProfileStore::ExecuteBootstrap(BootstrapAction action)');p.write_text(s)
p=r/'include/core/ProfileStore.hpp';s=p.read_text().replace('    bool LoadDirectory();','    bool LoadDirectory();\n    void PrepareBeginState(uint32_t expected, uint32_t required_root_format, bool recovery);\n    void PrepareInitializedRoot(unsigned slot);').replace('    TransactionResult PublishPreparedCommit(const Directory &);','    void PublishPreparedCommit(const Directory &);')
import re
for name in ['Rename','Reorder','Delete']:s=re.sub(r'    bool Prepare'+name+r'\([^\n]*\);','    bool Prepare'+name+'();',s)
p.write_text(s)
