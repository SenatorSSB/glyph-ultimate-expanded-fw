from pathlib import Path
root=Path('/private/tmp/glyph-native-final-review-bcb9824b')
s=(root/'.platformio-home/packages/framework-arduinopico/libraries/LittleFS/lib/littlefs/lfs.c').read_text()
s='extern int reviewer_deorphan_depth; extern void reviewer_after_dir_delete(void); extern void reviewer_on_compact(void);\n'+s
marker='static int lfs_fs_deorphan(lfs_t *lfs, bool powerloss) {'
assert s.count(marker)==1
s=s.replace(marker,'''static int reviewer_deorphan_impl(lfs_t *lfs, bool powerloss);
static int lfs_fs_deorphan(lfs_t *lfs, bool powerloss) {
    ++reviewer_deorphan_depth;
    int result=reviewer_deorphan_impl(lfs,powerloss);
    --reviewer_deorphan_depth;
    return result;
}
static int reviewer_deorphan_impl(lfs_t *lfs, bool powerloss) {''')
marker='''    lfs->mlist = dir.next;
    if (lfs_tag_type3(tag) == LFS_TYPE_DIR) {
        // fix orphan'''
assert s.count(marker)==1
s=s.replace(marker,'''    lfs->mlist = dir.next;
    if (lfs_tag_type3(tag) == LFS_TYPE_DIR) {
        reviewer_after_dir_delete();
        // fix orphan''')
marker='''static int lfs_dir_compact(lfs_t *lfs,
        lfs_mdir_t *dir, const struct lfs_mattr *attrs, int attrcount,
        lfs_mdir_t *source, uint16_t begin, uint16_t end) {'''
assert s.count(marker)==1;s=s.replace(marker,marker+'\n    reviewer_on_compact();')
Path('/private/tmp/glyph-native-broad-orphan-witness/lfs-observer.c').write_text(s)
