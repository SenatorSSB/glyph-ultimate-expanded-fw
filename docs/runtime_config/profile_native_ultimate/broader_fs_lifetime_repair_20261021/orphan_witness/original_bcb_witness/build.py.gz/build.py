from pathlib import Path
import subprocess,json,os
root=Path('/private/tmp/glyph-native-final-review-bcb9824b');prior=Path('/private/tmp/glyph-native-bcb9824b-store-dispatch-review');out=Path('/private/tmp/glyph-native-broad-orphan-witness')
np=root/'.pio/libdeps/glyph_mk6/Nanopb';lib=root/'.platformio-home/packages/framework-arduinopico/libraries/LittleFS/lib/littlefs'
flags=['-O2','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-non-c-typedef-for-linkage','-fshort-enums','-fsanitize=address,undefined','-fno-omit-frame-pointer','-DLFS_NAME_MAX=32','-DGLYPH_CHECKED_STORAGE_TEST_MOUNT=1','-DGLYPH_NATIVE_TARGET_METRICS=1','-DGLYPH_NATIVE_METRICS_HOST=1']
for p in [root/'tools/fixtures/stage_c_ultimate_profiles_host/include',prior/'generated',np,root/'include',root/'HAL/pico/include',root/'config/glyph/common/include',root/'config/glyph/glyph_mk6/include',root/'src',root/'tools/fixtures/profile_native_ultimate',root/'tools/fixtures/native_target_metrics/include',lib]:flags+=['-I',str(p)]
commands=[]
def run(argv):
 commands.append(argv);p=subprocess.run(argv,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','ASAN_OPTIONS':'detect_leaks=0'});print(p.stdout,end='',flush=True)
 if p.returncode:raise SystemExit(p.returncode)
run(['cc','-std=c11',*flags,'-c',str(out/'lfs-observer.c'),'-o',str(out/'lfs-observer.o')])
sources=['HAL/pico/src/core/CheckedStorage.cpp','src/core/config_validation.cpp','src/core/config_button_validation.cpp','src/core/config_usb_default_validation.cpp','src/core/config_rgb_target_validation.cpp','config/glyph/common/src/glyph_config_validation.cpp','src/modes/UltimateNativeProfile.cpp','src/modes/UltimateNativeEvaluator.cpp','src/modes/Ultimate.cpp','src/core/ControllerMode.cpp','src/core/InputMode.cpp','src/core/CommunicationBackend.cpp','src/core/socd.cpp']
objects=[prior/(n+'.o') for n in ['NativeTargetMetrics','runner_clock','pb_common','pb_encode','pb_decode','config.pb','lfs_util']]
run(['c++','-std=c++17',*flags,str(out/'witness.cpp'),str(prior/'mounted-native.cpp'),*[str(root/s) for s in sources],*[str(p) for p in objects],str(out/'lfs-observer.o'),'-o',str(out/'witness')])
run([str(out/'witness'),str(prior/'store-legacy.pb')])
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
