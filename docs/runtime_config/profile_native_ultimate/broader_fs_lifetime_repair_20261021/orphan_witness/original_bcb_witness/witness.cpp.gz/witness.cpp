#include "/private/tmp/glyph-native-broad-orphan-witness/native_store_include.cpp"
#include <csetjmp>
extern "C" {
int reviewer_deorphan_depth=0;
void reviewer_after_dir_delete();
void reviewer_on_compact();
}
static std::jmp_buf loss;
static bool cut_delete=false, cut_prog=false, gc_phase=false;
static unsigned orphan_compactions=0,gc_orphan_compactions=0,programs=0,gc_orphan_programs=0;
void reviewer_after_dir_delete() {if(cut_delete) {cut_delete=false;std::longjmp(loss,1);}}
void reviewer_on_compact() {if(reviewer_deorphan_depth) {++orphan_compactions;if(gc_phase)++gc_orphan_compactions;}}
static int observed_prog(const lfs_config*c,lfs_block_t b,lfs_off_t o,const void*p,lfs_size_t n) {
 ++programs;
 if(reviewer_deorphan_depth&&gc_phase)++gc_orphan_programs;
 if(cut_prog&&reviewer_deorphan_depth) {cut_prog=false;require(n>=1,"partial page bound");require(ram_prog(c,b,o,p,1)==0,"legal NOR partial program");std::longjmp(loss,2);}
 return ram_prog(c,b,o,p,n);
}
static CheckedStorage::Fault observe_gc(Kind,CheckedStorage::Operation op,CheckedStorage::Phase phase,const char *path) {
 if(op==CheckedStorage::Operation::Remove) {gc_phase=phase==CheckedStorage::Phase::Before;if(gc_phase)std::printf("actual_checked_remove=%s orphan_count=%u\n",path,unsigned(mounted_fs.gstate.tag&0x3ff));}
 return CheckedStorage::Fault::None;
}
static void remount() {require(lfs_unmount(&mounted_fs)==0,"release abandoned RAM caches only");mounted_fs={};reviewer_deorphan_depth=0;require(lfs_mount(&mounted_fs,&mounted_cfg)==0,"power loss remount");}
int main(int argc,char **argv) {
 try {
 require(argc==2,"legacy config input");std::ifstream f(argv[1],std::ios::binary);Bytes raw((std::istreambuf_iterator<char>(f)),{});auto decoder=pb_istream_from_buffer(raw.data(),raw.size());require(pb_decode(&decoder,Config_fields,&legacy),"legacy source decode");
 mounted_cfg.read=ram_read;mounted_cfg.prog=observed_prog;mounted_cfg.erase=ram_erase;mounted_cfg.sync=ram_sync;mounted_cfg.read_size=256;mounted_cfg.prog_size=256;mounted_cfg.block_size=4096;mounted_cfg.block_count=128;mounted_cfg.block_cycles=16;mounted_cfg.cache_size=256;mounted_cfg.lookahead_size=256;
 require(!lfs_format(&mounted_fs,&mounted_cfg)&&!lfs_mount(&mounted_fs,&mounted_cfg),"actual geometry mount");
 ProfileStore initial;require(initial.Begin(),"actual v2 bootstrap");require(initial.Create(legacy.ultimate_profiles[0],"protected",1,identity(1)).status==Status::Ok,"protected valid record");const auto incarnation=initial.Incarnation();
 require(!lfs_mkdir(&mounted_fs,"/unrelated"),"valid unrelated physical directory");
 const unsigned char marker=42;require(bool(CheckedStorage::WriteFile("/ultimate-00000100-00000001.tmp",&marker,1,Kind::Record)),"unprotected recognized garbage file");
 cut_delete=true;
 if(setjmp(loss)==0) {lfs_remove(&mounted_fs,"/unrelated");require(false,"first cut reached");}
 remount();require((mounted_fs.gstate.tag&0x3ff)>0,"committed positive orphan state");
 std::printf("after_first_loss orphan_count=%u gdisk=%08x\n",unsigned(mounted_fs.gstate.tag&0x3ff),unsigned(mounted_fs.gdisk.tag));
 cut_prog=true;
 if(setjmp(loss)==0) {lfs_remove(&mounted_fs,"/ultimate-00000100-00000001.tmp");require(false,"second cut during recovery program reached");}
 remount();require((mounted_fs.gstate.tag&0x3ff)>0,"partial uncommitted repair preserves orphan");
 ProfileStore reboot;programs=0;require(reboot.Begin(incarnation,2)&&reboot.Count()==1&&!reboot.IsReadOnlyRecovery(),"actual Begin accepts healthy roots with positive orphan");require(programs==0,"Begin read-only before first mutating operation");check_profile(reboot,1,legacy.ultimate_profiles[0]);
 orphan_compactions=gc_orphan_compactions=gc_orphan_programs=0;CheckedStorage::SetFaultHook(observe_gc);
 const auto created=reboot.Create(legacy.ultimate_profiles[1],"after recovery",2,identity(2));CheckedStorage::SetFaultHook(nullptr);
 require(created.status==Status::Ok,"actual Create succeeds after recovery");require(gc_orphan_compactions>0&&gc_orphan_programs>0,"actual Admit GC removal nests positive-orphan compaction and program");
 std::printf("PASS actual Begin+Create Admit GC CheckedRemove positive-orphan nested compact=%u prog=%u orphan_after=%u\n",gc_orphan_compactions,gc_orphan_programs,unsigned(mounted_fs.gstate.tag&0x3ff));require(lfs_unmount(&mounted_fs)==0,"final unmount");return 0;
 }catch(const std::exception&e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}
}
