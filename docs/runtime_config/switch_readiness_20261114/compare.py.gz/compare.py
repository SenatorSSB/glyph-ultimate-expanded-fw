"""Compare linked stack-frame and call shapes against accepted combined candidate."""
import collections
import gzip
import hashlib
import json
from pathlib import Path
import sys

baseline, fresh, output = map(Path, sys.argv[1:])
old_manifest = json.loads((baseline / 'manifest.json').read_text())
assert old_manifest['files']['firmware.uf2']['sha256'] == '6b3fd3e2f71b839e7448ab6b0daa54e5d4f1d6473d0df917849413e3f4227ddb'
def old(key):
    entry = old_manifest['files'][key]
    data = gzip.decompress((baseline / entry['stored']).read_bytes())
    assert hashlib.sha256(data).hexdigest() == entry['sha256']
    return json.loads(data)
g, h = old('resource/functions.json'), json.loads((fresh / 'functions.json').read_text())
def shape(f):
    return {'frame': f['resolved_frame_bytes'], **{
        key: sorted(e['name'] for e in f[key]) for key in ('calls', 'tail')
    }, 'indirect': sorted(e['instruction'] for e in f['indirect'])}

changes = [n for n in g.keys() & h.keys() if shape(g[n]) != shape(h[n])]
switch = 'NintendoSwitchBackend::SendReport()'
details = {n:{'old':shape(g[n]), 'new':shape(h[n])} for n in changes if n == switch}
root = shape(h[switch])
timer_calls = set(root['calls'] + root['tail']) - set(shape(g[switch])['calls'] + shape(g[switch])['tail'])
timer_shapes = {key:shape(h[key]) for key in timer_calls}
out = {'baseline':old_manifest['source'], 'baseline_elf':old_manifest['files']['firmware.elf']['sha256'],
       'candidate_elf':json.loads((fresh/'summary.json').read_text())['elf_sha256'],
       'function_count':[len(g),len(h)], 'added':sorted(h.keys() - g.keys()),
       'removed':sorted(g.keys() - h.keys()), 'changed':sorted(changes), 'switch':details,
       'added_callees':timer_shapes}
output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k != 'switch'}))
