"""Exhaustively compare Switch wire packing for single-bit inputs and all 16 hat masks."""
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile
import sys

repo = Path(sys.argv[1]).resolve()
os.chdir(repo)
spec=importlib.util.spec_from_file_location("fixture", repo/"tools/check_switch_readiness.py")
fixture=importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
body=(fixture.FIXTURE/"main.cpp").read_text()
body=body[:body.index("struct Backend :")] + '''
struct Backend : NintendoSwitchBackend {
    using NintendoSwitchBackend::NintendoSwitchBackend;
    OutputState outputs{};
    void UpdateOutputs() override { _outputs = outputs; }
};
int main() {
    InputState state{};
    Backend backend(state, nullptr, 0);
    for (unsigned bit=0; bit<32; ++bit) {
        for (unsigned hats=0; hats<16; ++hats) {
            backend.outputs.buttons = uint32_t(1) << bit;
            backend.outputs.dpadLeft = (hats & 1) != 0;
            backend.outputs.dpadRight = (hats & 2) != 0;
            backend.outputs.dpadDown = (hats & 4) != 0;
            backend.outputs.dpadUp = (hats & 8) != 0;
            backend.outputs.leftStickX = 32 + 4*bit;
            backend.outputs.leftStickY = 224 - 4*bit;
            backend.outputs.rightStickX = 128 + hats;
            backend.outputs.rightStickY = 128 - hats;
            backend.SendReport();
        }
    }
    check(reports.size()==512,"report count");
    for (const auto &report : reports) {
        check(std::fwrite(report.data(), 1, report.size(), stdout) == 8, "write");
    }
}
'''
with tempfile.TemporaryDirectory() as tmp:
    p=Path(tmp)
    sr=p/'probe.cpp'
    sr.write_text(body)
    packed=[]
    for rev in (fixture.PARENT, "0b9ef3afd1834ac7832871bca0651b67147840a2"):
        source=p/'wire.cpp'
        source.write_bytes(subprocess.check_output(["git","show",rev+":"+fixture.BACKEND]))
        includes=[fixture.FIXTURE/'include','tools/fixtures/stage_c_ultimate_profiles_host/include','include','HAL/pico/include','tools/fixtures/gp_config012_button_host/generated','tools/fixtures/gp_config012_button_host/nanopb']
        subprocess.run([os.environ.get('CXX','c++'), '-std=gnu++17','-fshort-enums','-DNDEBUG', *['-I'+str(path) for path in includes],source,sr,'src/core/CommunicationBackend.cpp','src/core/InputSource.cpp','-o',p/'wire'],check=True)
        packed.append(subprocess.check_output([p/'wire']))
    assert packed[0]==packed[1] and len(packed[0])==4096
    import hashlib
    print("PASS 512 ready reports (32 individual bits x 16 hat masks), 4096 packed bytes match parent; sha256", hashlib.sha256(packed[0]).hexdigest())
