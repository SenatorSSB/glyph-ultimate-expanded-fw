import hashlib
import json
from pathlib import Path
import sys
from elftools.elf.elffile import ELFFile

def descriptor(root):
    with (root/'firmware.elf').open('rb') as f:
        elf = ELFFile(f)
        sym, = elf.get_section_by_name('.symtab').get_symbol_by_name('_ZN21NintendoSwitchBackend11_descriptorE')
        sec = elf.get_section(sym['st_shndx'])
        start = sym['st_value'] - sec['sh_addr']
        return sec.data()[start:start+sym['st_size']]

old, new = map(Path, sys.argv[1:3])
a, b = map(descriptor, (old,new))
assert a == b and len(a) == 86
sha = bytes.fromhex(sys.argv[3])
assert sha in (new/'firmware.bin').read_bytes()
print(json.dumps(dict(descriptor_bytes=len(a), descriptor_sha256=hashlib.sha256(b).hexdigest(),
                      source_sha_present_in_binary=sha.hex())))
