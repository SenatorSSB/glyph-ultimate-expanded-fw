"""Replay the linked display-stack proof from a candidate ELF and pinned dependencies."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def shape(function):
    return [function["resolved_frame_bytes"],
            [e["name"] for e in function["calls"]],
            [e["name"] for e in function["tail"]],
            [x["instruction"] for x in function["indirect"]]]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("glyph", "elf", "platformio", "out"):
        parser.add_argument("--" + flag, type=Path, required=True)
    args = parser.parse_args()
    glyph, elf, pio, out = [p.resolve() for p in (args.glyph, args.elf, args.platformio, args.out)]
    reference = glyph / "docs/runtime_config/package_active_profile_display/resource"
    out.mkdir(parents=True, exist_ok=True)
    toolchain = pio / "packages/toolchain-rp2040-earlephilhower/bin"
    subprocess.run([sys.executable, reference/"extract.py", "--elf", elf, "--toolchain", toolchain,
                    "--output-dir", out], check=True, stdout=subprocess.DEVNULL)
    original = (reference/"retained-core1_bound.py").read_text()
    # The new named transfer callback replaces the second setup1 lambda. The
    # inherited concrete config menu renderer now delegates to DefaultConfigMenu.
    substitutions = {
        "r'(ConfigMenu|InputDisplay|": "r'(ConfigMenu|DefaultConfigMenu|InputDisplay|",
        "n.startswith('setup1::{lambda')]": "n.startswith('setup1::{lambda') or n=='transfer_dashboard()']",
    }
    oracle = original
    for old, new in substitutions.items():
        assert oracle.count(old) == 1
        oracle = oracle.replace(old, new)
    script = out / "candidate-core1-bound.py"
    script.write_text(oracle)
    subprocess.run([sys.executable, script, "--output-dir", out], check=True,
                   stdout=subprocess.DEVNULL)
    current_graph = json.loads((out/"core1-bound-graph.json").read_text())
    baseline_graph = json.loads((reference/"current-core1-bound-graph.json").read_text())
    old = json.loads(gzip.decompress((reference/"functions.json.gz").read_bytes()))
    new = json.loads((out/"functions.json").read_text())
    old_tables = json.loads(gzip.decompress((reference/"vtables.json.gz").read_bytes()))
    new_tables = json.loads((out/"vtables.json").read_text())
    pin_count = 0
    for pin in json.loads((reference/"lower-pin-comparison.json").read_text()):
        rel = pin["path"]
        source = pio/rel.removeprefix(".platformio-home/") if rel.startswith(".platformio-home/") else glyph/rel
        assert hashlib.sha256(source.read_bytes()).hexdigest() == pin["actual"], rel
        pin_count += 1
    assert not current_graph["unknown"]
    for name in baseline_graph["special_bounds"]:
        assert shape(old[name]) == shape(new[name]), name
    def slots(table):
        return [(s["offset_from_vptr"], s["name"]) for s in table]
    changed_tables = sorted(name for name in set(old_tables)|set(new_tables)
                            if slots(old_tables.get(name,[])) != slots(new_tables.get(name,[])))
    # The isolated startup build retains the baseline menu renderer. Combined
    # candidates override the renderer for the ordinary managed selector.
    selector_changed = "vtable for DefaultConfigMenu" in changed_tables
    selector_tables = ["vtable for DefaultConfigMenu", "vtable for GlyphConfigMenu"] if selector_changed else []
    for name in selector_tables:
        difference = [(x,y) for x,y in zip(slots(old_tables[name]), slots(new_tables[name])) if x != y]
        assert len(difference) == 1 and difference[0][0][0] == difference[0][1][0] == 16
        assert difference[0][1][1].startswith("DefaultConfigMenu::UpdateDisplay(")
    # The source reader vtable belongs to core0 and never appears in these
    # modeled dynamic target families. All others retain slot/name identity.
    accepted = "f4146bedebb50559454954b8e20c9b641aeba616"
    reader_path = "include/core/GlyphPackageSourceReader.hpp"
    original_reader = subprocess.check_output(["git", "show", accepted + ":" + reader_path], cwd=glyph)
    changed_reader = (glyph / reader_path).read_bytes() != original_reader
    reader_tables = ["vtable for GlyphPackageSourceReader"] if changed_reader else []
    assert changed_tables == sorted(selector_tables + reader_tables)
    rows = current_graph["bounds"]
    setup, loop = rows["setup1"]["bound"], rows["loop1"]["bound"]
    # Pinned non-RTOS outer wrappers and SIO IRQ source predicates documented
    # in the referenced display proof. Never infer measured high water.
    bound = 16 + max(setup,loop) + 68
    linked = json.loads((out/"summary.json").read_text())
    assert bound <= 1152 and linked["stack_reservations"] == [2048,2048]
    result = dict(elf_sha256=linked["elf_sha256"], static_ram=linked["static"],
        heap_capacity=linked["heap_capacity"], stack_reservations=linked["stack_reservations"],
        compared_lower_source_pins=pin_count, matched_special_leaf_shapes=len(baseline_graph["special_bounds"]),
        reachable_functions=current_graph["reachable_count"], unresolved_edges=current_graph["unknown"],
        changed_vtables=changed_tables, setup1=setup, loop1=loop, outer_wrappers=16, sio_irq=68,
        core1_bound=bound, retained_core1_budget=1152)
    (out/"display-stack-result.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
